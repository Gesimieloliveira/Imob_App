/*import * as React from 'react';
import { Button, View, Text } from 'react-native';


function Menu() {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>Ola pagina Menu</Text>
      </View>
    );
  }
  export default  Menu;*/

  
  import React, { Component } from 'react';
import { View } from 'react-native';

  export default class Menu extends Component {
    render(){
      return(
        <View>
          
        </View>
      )
    }
  }

  